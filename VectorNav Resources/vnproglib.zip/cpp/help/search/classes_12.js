var searchData=
[
  ['yawpitchrollmagneticaccelerationandangularratesregister',['YawPitchRollMagneticAccelerationAndAngularRatesRegister',['../structvn_1_1sensors_1_1_yaw_pitch_roll_magnetic_acceleration_and_angular_rates_register.html',1,'vn::sensors']]],
  ['yawpitchrolltruebodyaccelerationandangularratesregister',['YawPitchRollTrueBodyAccelerationAndAngularRatesRegister',['../structvn_1_1sensors_1_1_yaw_pitch_roll_true_body_acceleration_and_angular_rates_register.html',1,'vn::sensors']]],
  ['yawpitchrolltrueinertialaccelerationandangularratesregister',['YawPitchRollTrueInertialAccelerationAndAngularRatesRegister',['../structvn_1_1sensors_1_1_yaw_pitch_roll_true_inertial_acceleration_and_angular_rates_register.html',1,'vn::sensors']]]
];
