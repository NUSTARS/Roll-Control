var searchData=
[
  ['navdivisor',['navDivisor',['../structvn_1_1sensors_1_1_imu_rate_configuration_register.html#a12f187b906e369b211f93bb84c506b79',1,'vn::sensors::ImuRateConfigurationRegister']]],
  ['nedacc',['nedAcc',['../structvn_1_1sensors_1_1_gps_solution_lla_register.html#ac70c431a1eb40e702d113f1676cb82da',1,'vn::sensors::GpsSolutionLlaRegister']]],
  ['nedvel',['nedVel',['../structvn_1_1sensors_1_1_gps_solution_lla_register.html#a5dc28e1629cf7a3f1f51c8950cc42006',1,'vn::sensors::GpsSolutionLlaRegister::nedVel()'],['../structvn_1_1sensors_1_1_ins_solution_lla_register.html#ac9f3311d292d4e65f6f68180f6f7fb97',1,'vn::sensors::InsSolutionLlaRegister::nedVel()']]],
  ['neg',['neg',['../structvn_1_1math_1_1mat.html#aeda3112f2f4de7e4805dacc6adf4eea7',1,'vn::math::mat::neg()'],['../structvn_1_1math_1_1mat_3_012_00_012_00_01_t_01_4.html#a8c01a0feb3fa0e3e3b8ee2cb79ff472f',1,'vn::math::mat&lt; 2, 2, T &gt;::neg()'],['../structvn_1_1math_1_1mat_3_013_00_013_00_01_t_01_4.html#aea74fd3b5b1a18fae476db4a8f9da44b',1,'vn::math::mat&lt; 3, 3, T &gt;::neg()'],['../structvn_1_1math_1_1mat_3_014_00_014_00_01_t_01_4.html#aec5547714a60f7ef366997924af39f54',1,'vn::math::mat&lt; 4, 4, T &gt;::neg()'],['../structvn_1_1math_1_1vec.html#aed8ac97d844e7e803d1a0536630cc151',1,'vn::math::vec::neg()'],['../structvn_1_1math_1_1vec_3_012_00_01_t_01_4.html#a7fa8f86df6ee8097df65e4411de0e9aa',1,'vn::math::vec&lt; 2, T &gt;::neg()'],['../structvn_1_1math_1_1vec_3_013_00_01_t_01_4.html#acae5fb518980f6c803f8fd506a3aa6f3',1,'vn::math::vec&lt; 3, T &gt;::neg()'],['../structvn_1_1math_1_1vec_3_014_00_01_t_01_4.html#ab705429a30f26892a4a3840ccd470fd8',1,'vn::math::vec&lt; 4, T &gt;::neg()']]],
  ['nocopy',['NoCopy',['../classvn_1_1util_1_1_no_copy.html#a78ed195790fc251302755c01ef254488',1,'vn::util::NoCopy']]],
  ['nocopy',['NoCopy',['../classvn_1_1util_1_1_no_copy.html',1,'vn::util']]],
  ['nocopy_2eh',['nocopy.h',['../nocopy_8h.html',1,'']]],
  ['norm',['norm',['../structvn_1_1math_1_1vec.html#a12ee38e4566aa64fe2dca3f72ff8e9ac',1,'vn::math::vec::norm()'],['../structvn_1_1math_1_1vec_3_012_00_01_t_01_4.html#a1e388fe87642b146ace69d6686e46b7f',1,'vn::math::vec&lt; 2, T &gt;::norm()'],['../structvn_1_1math_1_1vec_3_013_00_01_t_01_4.html#a0b6fac5d456706c73b23ab300913a15d',1,'vn::math::vec&lt; 3, T &gt;::norm()'],['../structvn_1_1math_1_1vec_3_014_00_01_t_01_4.html#aaa4db9899e0e4b61c07e3c6f34bcf064',1,'vn::math::vec&lt; 4, T &gt;::norm()']]],
  ['norotation',['noRotation',['../classvn_1_1math_1_1_attitude_f.html#aabc4bde4a661989ac4c1bf04e7076b90',1,'vn::math::AttitudeF']]],
  ['not_5ffound',['not_found',['../classvn_1_1not__found.html',1,'vn']]],
  ['not_5fimplemented',['not_implemented',['../classvn_1_1not__implemented.html',1,'vn']]],
  ['not_5fsupported',['not_supported',['../classvn_1_1not__supported.html',1,'vn']]],
  ['null_5fpointer',['null_pointer',['../classvn_1_1null__pointer.html',1,'vn']]],
  ['numberofreceivedatadroppedsections',['NumberOfReceiveDataDroppedSections',['../classvn_1_1xplat_1_1_serial_port.html#ae3771ce7012231b19ae9d9c0662963d2',1,'vn::xplat::SerialPort']]],
  ['nummeas',['numMeas',['../structvn_1_1sensors_1_1_gps_compass_estimated_baseline_register.html#a29b7e6d2fa3f385ae1c29f5aaff9f70b',1,'vn::sensors::GpsCompassEstimatedBaselineRegister']]],
  ['numsats',['numSats',['../structvn_1_1sensors_1_1_gps_solution_lla_register.html#a0f683df94f1924ab514ab65a61b6e8c8',1,'vn::sensors::GpsSolutionLlaRegister::numSats()'],['../structvn_1_1sensors_1_1_gps_solution_ecef_register.html#abf8d0327ddbf7ce785bbdef75c722d85',1,'vn::sensors::GpsSolutionEcefRegister::numSats()'],['../classvn_1_1sensors_1_1_composite_data.html#a4fc29191d9599fc2d164c1f910273e6a',1,'vn::sensors::CompositeData::numSats()']]]
];
