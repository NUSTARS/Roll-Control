var searchData=
[
  ['kelvin2celsius',['kelvin2celsius',['../group__temperature__convertors.html#gac3abd35c1770b3dcb387a46b813c2874',1,'vn::math::kelvin2celsius(float tempInKelvin)'],['../group__temperature__convertors.html#ga6e4ef8354e6089e716b2d3be6a2b8333',1,'vn::math::kelvin2celsius(double tempInKelvin)']]],
  ['kelvin2fahren',['kelvin2fahren',['../group__temperature__convertors.html#ga660d5bbf0530531c2a8c2e67ec9e48fa',1,'vn::math::kelvin2fahren(float tempInKelvin)'],['../group__temperature__convertors.html#gaa6a52ea01238c0b7a544bc8efe14a404',1,'vn::math::kelvin2fahren(double tempInKelvin)']]],
  ['knownacceldisturbance',['knownAccelDisturbance',['../structvn_1_1protocol_1_1uart_1_1_vpe_status.html#aba4b956bed21e35bccf49fe4bd7d9e4b',1,'vn::protocol::uart::VpeStatus']]],
  ['known_20issues',['Known Issues',['../known_issues.html',1,'']]],
  ['knownmagdisturbance',['knownMagDisturbance',['../structvn_1_1protocol_1_1uart_1_1_vpe_status.html#a30171e3666acbf1e9fc143b925262006',1,'vn::protocol::uart::VpeStatus']]]
];
