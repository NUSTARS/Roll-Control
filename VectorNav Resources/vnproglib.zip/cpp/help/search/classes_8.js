var searchData=
[
  ['magneticaccelerationandangularratesregister',['MagneticAccelerationAndAngularRatesRegister',['../structvn_1_1sensors_1_1_magnetic_acceleration_and_angular_rates_register.html',1,'vn::sensors']]],
  ['magneticandgravityreferencevectorsregister',['MagneticAndGravityReferenceVectorsRegister',['../structvn_1_1sensors_1_1_magnetic_and_gravity_reference_vectors_register.html',1,'vn::sensors']]],
  ['magnetometercalibrationcontrolregister',['MagnetometerCalibrationControlRegister',['../structvn_1_1sensors_1_1_magnetometer_calibration_control_register.html',1,'vn::sensors']]],
  ['magnetometercompensationregister',['MagnetometerCompensationRegister',['../structvn_1_1sensors_1_1_magnetometer_compensation_register.html',1,'vn::sensors']]],
  ['mat',['mat',['../structvn_1_1math_1_1mat.html',1,'vn::math']]],
  ['mat_3c_202_2c_202_2c_20t_20_3e',['mat&lt; 2, 2, T &gt;',['../structvn_1_1math_1_1mat_3_012_00_012_00_01_t_01_4.html',1,'vn::math']]],
  ['mat_3c_203_2c_203_2c_20t_20_3e',['mat&lt; 3, 3, T &gt;',['../structvn_1_1math_1_1mat_3_013_00_013_00_01_t_01_4.html',1,'vn::math']]],
  ['mat_3c_204_2c_204_2c_20t_20_3e',['mat&lt; 4, 4, T &gt;',['../structvn_1_1math_1_1mat_3_014_00_014_00_01_t_01_4.html',1,'vn::math']]],
  ['memoryport',['MemoryPort',['../classvn_1_1util_1_1_memory_port.html',1,'vn::util']]]
];
