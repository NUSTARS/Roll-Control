var searchData=
[
  ['type_5fascii',['TYPE_ASCII',['../structvn_1_1protocol_1_1uart_1_1_packet.html#ab12e361c05cfb93a80bff21a69ccac30a16b4e42d7a654e579902e1041c9c9d89',1,'vn::protocol::uart::Packet']]],
  ['type_5fbinary',['TYPE_BINARY',['../structvn_1_1protocol_1_1uart_1_1_packet.html#ab12e361c05cfb93a80bff21a69ccac30a259782d1109faf2b93eb8fffd37fc8b2',1,'vn::protocol::uart::Packet']]],
  ['type_5funknown',['TYPE_UNKNOWN',['../structvn_1_1protocol_1_1uart_1_1_packet.html#ab12e361c05cfb93a80bff21a69ccac30a38e391e6fd94db9f720be7a1cd2ac838',1,'vn::protocol::uart::Packet']]]
];
