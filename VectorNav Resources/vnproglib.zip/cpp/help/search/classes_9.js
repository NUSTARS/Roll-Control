var searchData=
[
  ['nocopy',['NoCopy',['../classvn_1_1util_1_1_no_copy.html',1,'vn::util']]],
  ['not_5ffound',['not_found',['../classvn_1_1not__found.html',1,'vn']]],
  ['not_5fimplemented',['not_implemented',['../classvn_1_1not__implemented.html',1,'vn']]],
  ['not_5fsupported',['not_supported',['../classvn_1_1not__supported.html',1,'vn']]],
  ['null_5fpointer',['null_pointer',['../classvn_1_1null__pointer.html',1,'vn']]]
];
