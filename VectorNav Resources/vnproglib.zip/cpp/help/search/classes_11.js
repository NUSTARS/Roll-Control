var searchData=
[
  ['vec',['vec',['../structvn_1_1math_1_1vec.html',1,'vn::math']]],
  ['vec_3c_202_2c_20t_20_3e',['vec&lt; 2, T &gt;',['../structvn_1_1math_1_1vec_3_012_00_01_t_01_4.html',1,'vn::math']]],
  ['vec_3c_203_2c_20double_20_3e',['vec&lt; 3, double &gt;',['../structvn_1_1math_1_1vec.html',1,'vn::math']]],
  ['vec_3c_203_2c_20t_20_3e',['vec&lt; 3, T &gt;',['../structvn_1_1math_1_1vec_3_013_00_01_t_01_4.html',1,'vn::math']]],
  ['vec_3c_204_2c_20t_20_3e',['vec&lt; 4, T &gt;',['../structvn_1_1math_1_1vec_3_014_00_01_t_01_4.html',1,'vn::math']]],
  ['velocitycompensationcontrolregister',['VelocityCompensationControlRegister',['../structvn_1_1sensors_1_1_velocity_compensation_control_register.html',1,'vn::sensors']]],
  ['velocitycompensationstatusregister',['VelocityCompensationStatusRegister',['../structvn_1_1sensors_1_1_velocity_compensation_status_register.html',1,'vn::sensors']]],
  ['vnsensor',['VnSensor',['../classvn_1_1sensors_1_1_vn_sensor.html',1,'vn::sensors']]],
  ['vpeaccelerometeradvancedtuningregister',['VpeAccelerometerAdvancedTuningRegister',['../structvn_1_1sensors_1_1_vpe_accelerometer_advanced_tuning_register.html',1,'vn::sensors']]],
  ['vpeaccelerometerbasictuningregister',['VpeAccelerometerBasicTuningRegister',['../structvn_1_1sensors_1_1_vpe_accelerometer_basic_tuning_register.html',1,'vn::sensors']]],
  ['vpebasiccontrolregister',['VpeBasicControlRegister',['../structvn_1_1sensors_1_1_vpe_basic_control_register.html',1,'vn::sensors']]],
  ['vpegyrobasictuningregister',['VpeGyroBasicTuningRegister',['../structvn_1_1sensors_1_1_vpe_gyro_basic_tuning_register.html',1,'vn::sensors']]],
  ['vpemagnetometeradvancedtuningregister',['VpeMagnetometerAdvancedTuningRegister',['../structvn_1_1sensors_1_1_vpe_magnetometer_advanced_tuning_register.html',1,'vn::sensors']]],
  ['vpemagnetometerbasictuningregister',['VpeMagnetometerBasicTuningRegister',['../structvn_1_1sensors_1_1_vpe_magnetometer_basic_tuning_register.html',1,'vn::sensors']]],
  ['vpestatus',['VpeStatus',['../structvn_1_1protocol_1_1uart_1_1_vpe_status.html',1,'vn::protocol::uart']]]
];
