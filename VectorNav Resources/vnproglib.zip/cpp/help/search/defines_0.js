var searchData=
[
  ['vnapi_5fmajor',['VNAPI_MAJOR',['../utilities_8h.html#aab6dd0dc3c5fdaefada12ee96f577300',1,'utilities.h']]]
];
