var searchData=
[
  ['vnsensor_20events',['VnSensor Events',['../group__vn_sensor_events.html',1,'']]],
  ['vnsensor_20properties',['VnSensor Properties',['../group__vn_sensor_properties.html',1,'']]]
];
